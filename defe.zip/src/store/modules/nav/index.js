export default {
  namespaced: true,
  state: {
    navToggle: false,
    navMenuicon: true,
  },
  mutations: {},
  actions: {},
};
